<template>
  <v-app>
    <v-container>
      <h1>Canlı Döviz Kuru</h1>
      <v-card>
        <v-card-title>Dolar (USD)</v-card-title>
        <v-card-text>
          <div>{{ usdRate }} TL</div>
        </v-card-text>
      </v-card>
      <v-card>
        <v-card-title>Euro (EUR)</v-card-title>
        <v-card-text>
          <div>{{ eurRate }} TL</div>
        </v-card-text>
      </v-card>
    </v-container>
  </v-app>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      usdRate: null,
      eurRate: null,
    };
  },
  mounted() {
    this.getExchangeRates();
  },
  methods: {
    async getExchangeRates() {
      try {
        const response = await axios.get('https://api.exchangerate-api.com/v4/latest/TRY');
        const rates = response.data.rates;
        this.usdRate = rates.USD.toFixed(2);
        this.eurRate = rates.EUR.toFixed(2);
      } catch (error) {
        console.error('Döviz kurları çekilirken bir hata oluştu:', error);
      }
    },
  },
};
</script>
