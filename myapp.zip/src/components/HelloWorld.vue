<template>
  <div class="container">
    <div class="header-left ">
      <div class="logo">
              <h1>Logo Gelecek</h1>

      </div>
      <div>
        <Havadurumu/>
        <!-- hava durumu gelcek burda yazıyodu -->
      </div>
    </div>
    <div class="header-right ">
      <div class="right-top">
      <h1>Değişmez İlkemiz</h1>

      </div>
      <div class="right-bottom">
        <Doviz/>
        <label >{{"kur gelecek"}}</label>


      </div>
    </div>
  </div>
</template>
<script>
import axios from "axios";
import Havadurumu from "./havadurumu.vue"
import Doviz from "./dövizkuru.vue"
export default {
  components : {Havadurumu,Doviz},
  name: 'HelloWorld',

  data: () => ({
   
  }),
  created(){
    this.fetchExchangeRates()
    // this.getExchangeRates()
  },
  methods : {
    async fetchExchangeRates() {
      try {
        const response = await fetch('https://www.tcmb.gov.tr/kurlar/today.xml');
        const xmlText = await response.text();
        debugger
        console.log(xmlText)
        // Now you can parse the XML and extract the data you need
        // Depending on the structure of the XML, you might need to use a library for XML parsing
        // For example, you can use the xml2js library: https://www.npmjs.com/package/xml2js
      } catch (error) {
        console.error('Error fetching exchange rates:', error);
      }
    },
    getExchangeRates() {
      var config = {
      method: 'get',
      url: 'https://www.tcmb.gov.tr/kurlar/today.xml',
      headers: { 
        'Accept' : 'application/json'
      }
    };
    debugger
    axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data));
    })
    .catch(function (error) {
      console.log(error);
    });
    }
  }
}
</script>
<style scoped>
.container{
  height: 250px;
  background-color: blue;
  display: flex;
  width: 100%;
}
.header-left{
  background-color: yellow;
  width: 500px;

}
.header-right{
  margin-left :0.5rem;
  background-color: orange;
  width: 100%;
  border-bottom-left-radius: 80px;
}
.logo{
  width: 100%;
  height: 65%;
  background-color: aqua;
  border-style: solid;
  border-bottom-right-radius: 80px;
  border: 2px solid black;
}

</style>
