<template>
  <v-app>
    <v-container>
      <h1>Canlı Hava Durumu - İzmir</h1>
      <v-card>
        <v-card-title>{{ city }}</v-card-title>
        <v-card-text>
          
          <div>Sıcaklık: {{ temperature }}°C</div>
          <div>Saat: {{ currentTime }}</div>
          <div>Tarih: {{ currentDate }}</div>
          <v-img :src="weatherIconUrl" max-width="100"></v-img>
        </v-card-text>
      </v-card>
    </v-container>
  </v-app>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      city: 'İzmir',
      weather: '',
      temperature: '',
      currentTime: '',
      currentDate: '',
      weatherIconCode: '', // Hava durumu ikon kodu
    };
  },
  mounted() {
    this.getCityWeather();
    this.getCurrentTimeAndDate();
  },
  methods: {
    async getCityWeather() {
      const apiKey = '2c801a5eb9a6f592fcec51be239c21f1'; // Kendi API anahtarınızı buraya ekleyin

      try {
        const response = await axios.get(`http://api.openweathermap.org/data/2.5/weather?q=${this.city}&appid=${apiKey}&units=metric`);
        this.weather = response.data.weather[0].description;
        this.temperature = response.data.main.temp.toFixed(1);
        this.weatherIconCode = response.data.weather[0].icon; // Hava durumu ikon kodunu al
      } catch (error) {
        console.error('Hava durumu verileri çekilirken bir hata oluştu:', error);
      }
    },
    getCurrentTimeAndDate() {
    const now = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', hour12: false, timeZoneName: 'short' };
    const turkishDate = now.toLocaleDateString('tr-TR', options);
    this.currentTime = turkishDate;
    }

  },
  computed: {
    weatherIconUrl() {
      // Hava durumu ikonunun tam URL'sini oluşturun
      return `http://openweathermap.org/img/w/${this.weatherIconCode}.png`;
    },
  },
};
</script>
